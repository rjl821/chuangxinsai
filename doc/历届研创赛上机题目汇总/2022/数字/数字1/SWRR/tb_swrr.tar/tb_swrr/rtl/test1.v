`timescale 1ns/1ps
module test1 (
    input           clk_sys     ,
    input           rst_n       ,
    output          value_valid 
);
assign value_valid = rst_n;
endmodule
