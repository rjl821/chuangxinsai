#!/bin/bash
#cd /home/ennocad/zytest/tb_swrr
ls -l
make clean
make comp1 elab run
make clean
make comp2 elab run
make clean
make comp3 elab run 
make clean
make comp4 elab run
make clean
make comp5 elab run
echo "-----------------------------------------"
for i in `ls ./print`; do cat ./print/$i;done
echo "-----------------------------------------"

