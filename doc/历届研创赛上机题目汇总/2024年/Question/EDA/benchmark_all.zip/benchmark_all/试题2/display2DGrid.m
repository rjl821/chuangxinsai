function display2DGrid(grid, nets)
    %标记端口
    for i = 1:length(nets)
        for j = 1:size(nets{i}, 1)
            x = nets{i}(j, 1);
            y = nets{i}(j, 2);
            grid(x, y) = grid(x, y) - 5;
        end
    end

    figure;
    [rows,cols] = size(grid);
    colormap("parula");
    maze = grid;
    plotmaze = ones(rows+1,cols+1);
    plotmaze(1:rows,1:cols) = maze;
    pcolor([1:cols+1],[1:rows+1],plotmaze);
    axis off;
    axis equal;
    set(gca, 'YDir', 'reverse');
    colorbar


end