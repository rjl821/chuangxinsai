/*
    文件明： asic.v
    文件描述： 可配置图像预处理ASIC模块顶层文件
*/
module asic(
   input          clk_sys      // |<s
  ,input          reset_sys    // |<s
  ,input          InVSYNC      // |<i
  ,input          InHSYNC      // |<i
  ,input          InEN         // |<i
  ,input  [7:0]   InData       // |<i
  ,input          CFG_VALID    // |<i
  ,input  [7:0]   CFG_REG      // |<i
  ,output         OutVSYNC     // |>o
  ,output         OutHSYNC     // |>o
  ,output         OutEN        // |>o
  ,output [7:0]   OutData      // |>o
);
//--------------  参赛选手作答区  ------------------


//---------------  作答区分割线  -------------------
endmodule
