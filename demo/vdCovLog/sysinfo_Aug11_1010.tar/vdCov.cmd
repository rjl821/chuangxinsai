verdiWindowResize -win $_vdCoverage_1 "829" "289" "900" "700"
gui_set_pref_value -category {coveragesetting} -key {geninfodumping} -value 1
gui_exclusion -set_force true
gui_assert_mode -mode flat
gui_class_mode -mode hier
gui_column_config -id   -list  covtblCcexList  -col  C  -show 
gui_column_config -id   -list  covtblCcexList  -col  C  -on   -show 
gui_column_config -id   -list  covtblCcexList  -col  X  -on   -show 
gui_excl_mgr_flat_list -on  0
gui_covdetail_select -id  CovDetail.1   -name   Line
verdiWindowWorkMode -win $_vdCoverage_1 -coverageAnalysis
gui_open_cov  -hier /home/jjt/chuangxinsai/demo/build/vcs/sv/cov/merged.vdb -testdir {} -test {/home/jjt/chuangxinsai/demo/build/vcs/sv/cov/merged/merged} -merge MergedTest -db_max_tests 10 -fsm transition
verdiWindowResize -win $_vdCoverage_1 "0" "0" "1040" "711"
